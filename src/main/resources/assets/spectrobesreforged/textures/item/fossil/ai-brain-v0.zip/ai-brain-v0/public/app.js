// app.js
const WS_URL = `ws://${location.host}/ws`;

const toggleBtn = document.querySelector("#toggle");
const cancelBtn = document.querySelector("#cancel");
const statusEl = document.querySelector("#status");
const logEl = document.querySelector("#log");

// Panel debug (columna derecha)
const dbgModel = document.querySelector("#dbg_model");
const dbgModalities = document.querySelector("#dbg_modalities");
const dbgBase = document.querySelector("#dbg_base");
const dbgTone = document.querySelector("#dbg_tone");
const dbgRules = document.querySelector("#dbg_rules");
const dbgContext = document.querySelector("#dbg_context");
const dbgFinal = document.querySelector("#dbg_final");

let ws;
let isOn = false;

let audioCtx;
let sourceNode;
let processorNode;
let micStream;

// salida
let playQueue = [];
let isPlaying = false;
let currentPlaybackNode = null;

const TARGET_RATE = 24000;

// evitar commit vacío
let sentSamples = 0;
const MIN_MS = 150;
const MIN_SAMPLES = Math.floor(TARGET_RATE * (MIN_MS / 1000));

// medidor
let meterTimer = null;

/* =========================
   LOG COLOREADO
   ========================= */
const MAX_LOG_LINES = 250;

function levelClassFromLine(line) {
  const t = (line || "").trimStart().toUpperCase();
  if (t.startsWith("[OK]")) return "log-ok";
  if (t.startsWith("[INFO]")) return "log-info";
  if (t.startsWith("[WARNING]") || t.startsWith("[WARN]")) return "log-warning";
  if (t.startsWith("[ERROR]")) return "log-error";
  return "log-info";
}

function log(line) {
  if (!logEl) return;

  const div = document.createElement("div");
  div.className = `log-line ${levelClassFromLine(line)}`;
  div.textContent = line;

  // Lo más nuevo arriba
  logEl.prepend(div);

  // Recortar por número de líneas
  while (logEl.childNodes.length > MAX_LOG_LINES) {
    logEl.removeChild(logEl.lastChild);
  }
}

function setStatus(s) {
  if (statusEl) statusEl.textContent = s;
}

/* =========================
   DEBUG PANEL (derecha)
   ========================= */
function setText(el, value) {
  if (!el) return;
  el.textContent =
    value === undefined || value === null || value === "" ? "—" : String(value);
}

function renderAssistantDebug(dbg) {
  if (!dbg) return;

  setText(dbgModel, dbg.model);
  setText(
    dbgModalities,
    Array.isArray(dbg.output_modalities)
      ? dbg.output_modalities.join(", ")
      : dbg.output_modalities
  );

  setText(dbgBase, dbg.base_instructions);
  setText(dbgTone, dbg.tone);
  setText(dbgRules, dbg.rules);

  if (dbg.context && typeof dbg.context === "object") {
    setText(dbgContext, JSON.stringify(dbg.context, null, 2));
  } else {
    setText(dbgContext, dbg.context);
  }

  setText(dbgFinal, dbg.final_instructions);
}

/* =========================
   AUDIO HELPERS
   ========================= */
function base64ToUint8(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

// Resample lineal
function resampleLinear(input, inRate, outRate) {
  if (inRate === outRate) return input;
  const ratio = inRate / outRate;
  const outLen = Math.floor(input.length / ratio);
  const out = new Float32Array(outLen);

  for (let i = 0; i < outLen; i++) {
    const idx = i * ratio;
    const i0 = Math.floor(idx);
    const i1 = Math.min(i0 + 1, input.length - 1);
    const frac = idx - i0;
    out[i] = input[i0] * (1 - frac) + input[i1] * frac;
  }
  return out;
}

function floatToPCM16(float32) {
  const pcm = new Int16Array(float32.length);
  for (let i = 0; i < float32.length; i++) {
    let s = Math.max(-1, Math.min(1, float32[i]));
    pcm[i] = s < 0 ? s * 32768 : s * 32767;
  }
  return pcm;
}

function pcm16ToBase64(pcm16) {
  const u8 = new Uint8Array(pcm16.buffer);
  let bin = "";
  for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
  return btoa(bin);
}

function pcm16ToFloat32(pcm16) {
  const f32 = new Float32Array(pcm16.length);
  for (let i = 0; i < pcm16.length; i++) f32[i] = pcm16[i] / 32768;
  return f32;
}

/* =========================
   WS CONNECT
   ========================= */
async function connectWS() {
  return new Promise((resolve, reject) => {
    ws = new WebSocket(WS_URL);

    ws.onopen = () => {
      setStatus("Conectado");
      resolve();
    };

    ws.onerror = reject;

    ws.onclose = () => {
      setStatus("Desconectado");
      ws = null;
    };

    ws.onmessage = (ev) => {
      let data;
      try {
        data = JSON.parse(ev.data);
      } catch {
        return;
      }

      // Debug del server
      if (data.type === "assistant_debug") {
        renderAssistantDebug(data.debug);
        log("[INFO] Debug de asistente recibido");
        return;
      }

      if (data.type === "ready") log("[INFO] WS listo");
      if (data.type === "error") log("[ERROR] " + data.message);

      if (data.source === "openai") {
        const msg = data.msg;

        // ver si la API “ve” tu audio
        if (msg.type === "input_audio_buffer.committed")
          log("[INFO] input_audio_buffer.committed");
        if (msg.type === "input_audio_buffer.cleared")
          log("[INFO] input_audio_buffer.cleared");

        if (msg.type === "response.created") log("[INFO] Respuesta creada");
        if (msg.type === "response.done") log("[OK] Respuesta ejecutada");

        if (msg.type === "response.output_audio.delta") {
          playQueue.push(msg.delta);
          if (!isPlaying) playFromQueue();
        }

        if (msg.type === "error") {
          log("[ERROR] " + (msg.error?.message || "error"));
        }
      }
    };
  });
}

/* =========================
   AUDIO CONTEXT + MIC
   ========================= */
async function ensureAudioContext() {
  if (!audioCtx)
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if (audioCtx.state === "suspended") {
    try {
      await audioCtx.resume();
    } catch {}
  }
}

async function startMic() {
  await ensureAudioContext();

  micStream = await navigator.mediaDevices.getUserMedia({ audio: true });

  // en algunos setups, ayuda re-resume tras permisos
  try {
    await audioCtx.resume();
  } catch {}

  sourceNode = audioCtx.createMediaStreamSource(micStream);

  // más frecuente que 4096 para que “suba” antes el medidor
  processorNode = audioCtx.createScriptProcessor(2048, 1, 1);

  processorNode.onaudioprocess = (e) => {
    if (!isOn || !ws || ws.readyState !== 1) return;

    const input = e.inputBuffer.getChannelData(0);
    const resampled = resampleLinear(input, audioCtx.sampleRate, TARGET_RATE);
    const pcm16 = floatToPCM16(resampled);

    sentSamples += pcm16.length;

    ws.send(JSON.stringify({ type: "audio", audio_b64: pcm16ToBase64(pcm16) }));
  };

  sourceNode.connect(processorNode);
  processorNode.connect(audioCtx.destination);
}

function stopMic() {
  try {
    processorNode?.disconnect();
  } catch {}
  try {
    sourceNode?.disconnect();
  } catch {}
  if (micStream) micStream.getTracks().forEach((t) => t.stop());

  micStream = null;
  processorNode = null;
  sourceNode = null;
}

/* =========================
   PLAYBACK
   ========================= */
function stopPlayback() {
  playQueue.length = 0;
  isPlaying = false;
  try {
    if (currentPlaybackNode) {
      currentPlaybackNode.onended = null;
      currentPlaybackNode.stop();
      currentPlaybackNode.disconnect();
    }
  } catch {}
  currentPlaybackNode = null;
}

async function playFromQueue() {
  isPlaying = true;
  await ensureAudioContext();

  while (playQueue.length) {
    const b64 = playQueue.shift();
    const bytes = base64ToUint8(b64);
    const pcm16 = new Int16Array(
      bytes.buffer,
      bytes.byteOffset,
      bytes.byteLength / 2
    );
    const float32 = pcm16ToFloat32(pcm16);

    const buffer = audioCtx.createBuffer(1, float32.length, TARGET_RATE);
    buffer.getChannelData(0).set(float32);

    await new Promise((resolve) => {
      const node = audioCtx.createBufferSource();
      currentPlaybackNode = node;
      node.buffer = buffer;
      node.connect(audioCtx.destination);
      node.onended = () => {
        if (currentPlaybackNode === node) currentPlaybackNode = null;
        resolve();
      };
      node.start();
    });

    if (!isPlaying) break;
  }

  isPlaying = false;
}

/* =========================
   METER
   ========================= */
function startMeter() {
  stopMeter();
  meterTimer = setInterval(() => {
    const ms = Math.round((sentSamples / TARGET_RATE) * 1000);
    setStatus(`Conectado · Enviando: ${ms}ms`);
  }, 250);
}

function stopMeter() {
  if (meterTimer) clearInterval(meterTimer);
  meterTimer = null;
  setStatus(ws && ws.readyState === 1 ? "Conectado" : "Desconectado");
}

/* =========================
   PTT ON/OFF
   ========================= */
async function turnOn() {
  if (!ws || ws.readyState !== 1) await connectWS();

  // patrón push-to-talk: limpiar buffer antes de hablar
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: "cancel" }));
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: "clear" }));
  stopPlayback();

  sentSamples = 0;
  await startMic();

  isOn = true;
  toggleBtn.textContent = "ON";
  toggleBtn.classList.add("on");
  log("[INFO] ON: grabando…");
  startMeter();
}

function turnOff() {
  isOn = false;
  toggleBtn.textContent = "OFF";
  toggleBtn.classList.remove("on");

  stopMic();
  stopMeter();

  // Al soltar, si hay audio suficiente: commit + respond
  if (ws && ws.readyState === 1) {
    if (sentSamples >= MIN_SAMPLES) {
      ws.send(JSON.stringify({ type: "commit" }));
      ws.send(JSON.stringify({ type: "respond" }));
      log("[INFO] OFF: commit + respond");
    } else {
      ws.send(JSON.stringify({ type: "clear" }));
      log("[WARN] OFF: muy poco audio, clear");
    }
  }
}

/* =========================
   UI EVENTS
   ========================= */
toggleBtn.onclick = async () => {
  try {
    if (!isOn) await turnOn();
    else turnOff();
  } catch (e) {
    console.error(e);
    log("[ERROR] Error. Mira consola del navegador y logs del server.");
  }
};

cancelBtn.onclick = () => {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: "cancel" }));
  stopPlayback();
  log("[INFO] cancel + stop playback");
};
