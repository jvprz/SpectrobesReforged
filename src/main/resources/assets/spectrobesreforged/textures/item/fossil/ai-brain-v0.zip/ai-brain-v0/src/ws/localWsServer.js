// src/ws/localWsServer.js
const WebSocket = require("ws");
const { buildAssistantPrompt } = require("../config/buildAssistantPrompt");


function attachLocalWsServer(server) {
  const wss = new WebSocket.Server({ server, path: "/ws" });

  wss.on("connection", (client) => {
    console.log("[INFO] Front conectado a /ws");

    const apiKey = process.env.OPENAI_API_KEY;
    const model = process.env.OPENAI_REALTIME_MODEL || "gpt-realtime";

    if (!apiKey) {
      safeSendClient(client, { type: "error", message: "Falta OPENAI_API_KEY en .env" });
      client.close();
      return;
    }

    const oai = new WebSocket(
      `wss://api.openai.com/v1/realtime?model=${encodeURIComponent(model)}`,
      { headers: { Authorization: `Bearer ${apiKey}` } }
    );

    let configured = false;

    // --- OpenAI WS lifecycle ---
    oai.on("open", () => {
      console.log("[INFO] Conectado a OpenAI Realtime");
      safeSendClient(client, { type: "ready" });
    });

    oai.on("close", (code, reason) => {
      const r = reason?.toString?.() || "";
      console.log(`[INFO] OpenAI WS cerrado code=${code} reason=${r}`);
      safeSendClient(client, { type: "closed", who: "openai", code, reason: r });
      try { client.close(); } catch { }
    });

    oai.on("error", (err) => {
      console.error("OpenAI WS error:", err?.message || err);
      safeSendClient(client, { type: "error", message: "Error en conexión con OpenAI Realtime" });
      try { client.close(); } catch { }
    });

    oai.on("message", (data) => {
      let msg;
      try {
        msg = JSON.parse(data.toString());
      } catch {
        return;
      }

      // Configurar sesión una sola vez (cuando el server crea la sesión)
      if (!configured && msg.type === "session.created") {
        configured = true;
        const base = process.env.ASSISTANT_BASE_INSTRUCTIONS || "";
        const tone = process.env.ASSISTANT_TONE || "";
        const rules = process.env.ASSISTANT_RULES || "";

        const context = { id: "cli_123", name: "Juan Pérez", plan: "Premium" };

        const finalInstructions =
          `${base}\n\n${tone}\n\n${rules}\n\n[CONTEXTO]\n${JSON.stringify(context, null, 2)}`;

        safeSendOai(oai, {
          type: "session.update",
          session: {
            type: "realtime",
            instructions: finalInstructions,
            output_modalities: ["audio"],
            audio: {
              input: {
                format: { type: "audio/pcm", rate: 24000 },
                turn_detection: null,
              },
              output: { format: { type: "audio/pcm", rate: 24000 } },
            },
          },
        });

        safeSendClient(client, {
          type: "assistant_debug",
          debug: {
            model,
            output_modalities: ["audio"],
            base_instructions: base,
            tone,
            rules,
            context,
            final_instructions: finalInstructions,
          },
        });


      }

      // Reenviar todo al front (debug + response.output_audio.delta)
      safeSendClient(client, { source: "openai", msg });
    });

    // --- Front WS lifecycle ---
    client.on("message", (raw) => {
      let payload;
      try {
        payload = JSON.parse(raw.toString());
      } catch {
        return;
      }

      if (oai.readyState !== WebSocket.OPEN) return;

      switch (payload.type) {
        case "clear": {
          // Limpia buffer de entrada (PTT típico al empezar a hablar)
          safeSendOai(oai, { type: "input_audio_buffer.clear" });
          break;
        }

        case "audio": {
          // audio_b64 debe ser PCM16 base64 a 24k (tu front lo hace)
          if (typeof payload.audio_b64 === "string" && payload.audio_b64.length) {
            safeSendOai(oai, { type: "input_audio_buffer.append", audio: payload.audio_b64 });
          }
          break;
        }

        case "commit": {
          // Cierra buffer + pide respuesta (audio-only)
          safeSendOai(oai, { type: "input_audio_buffer.commit" });
          break;
        }

        case "respond": {
          safeSendOai(oai, {
            type: "response.create",
            response: { output_modalities: ["audio"] },
          });
          break;
        }

        case "cancel": {
          // Corta la respuesta en curso
          safeSendOai(oai, { type: "response.cancel" });
          break;
        }

        // (Opcional) debug text: si lo usas, pide output_modalities ['audio'] o ['text'] según tu API.
        case "text": {
          if (typeof payload.text === "string" && payload.text.trim()) {
            safeSendOai(oai, {
              type: "conversation.item.create",
              item: {
                type: "message",
                role: "user",
                content: [{ type: "input_text", text: payload.text }],
              },
            });
            safeSendOai(oai, {
              type: "response.create",
              response: { output_modalities: ["audio"] },
            });
          }
          break;
        }

        default:
          // ignore
          break;
      }
    });

    client.on("close", () => {
      console.log("[INFO] Front desconectado de /ws");
      try { oai.close(); } catch { }
    });

    client.on("error", (err) => {
      console.error("Front WS error:", err?.message || err);
      try { oai.close(); } catch { }
    });
  });

  console.log("[INFO] WS local listo en /ws");
}

// Helpers
function safeSendClient(client, obj) {
  try {
    if (client.readyState === WebSocket.OPEN) client.send(JSON.stringify(obj));
  } catch { }
}

function safeSendOai(oai, obj) {
  try {
    if (oai.readyState === WebSocket.OPEN) oai.send(JSON.stringify(obj));
  } catch { }
}

module.exports = { attachLocalWsServer };
