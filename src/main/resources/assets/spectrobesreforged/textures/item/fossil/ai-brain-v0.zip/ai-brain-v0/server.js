require("dotenv").config();

const http = require("http");
const { createApp } = require("./src/http/app");
const { attachLocalWsServer } = require("./src/ws/localWsServer");

const PORT = process.env.PORT || 3000;

const app = createApp();
const server = http.createServer(app);

// WS local en /ws
attachLocalWsServer(server);

server.listen(PORT, () => {
  console.log("Server en http://localhost:" + PORT);
});
