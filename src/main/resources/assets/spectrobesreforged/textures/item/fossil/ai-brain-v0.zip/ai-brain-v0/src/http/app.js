const express = require("express");
const path = require("path");

function createApp() {
  const app = express();

  app.get("/health", (_, res) => res.json({ ok: true }));

  app.use(express.static(path.join(process.cwd(), "public")));

  return app;
}

module.exports = { createApp };
