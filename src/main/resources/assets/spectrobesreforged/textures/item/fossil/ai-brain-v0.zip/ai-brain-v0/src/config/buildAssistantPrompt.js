function buildAssistantPrompt({ context = null }) {
  const base = process.env.ASSISTANT_BASE_INSTRUCTIONS || "";
  const tone = process.env.ASSISTANT_TONE || "";
  const rules = process.env.ASSISTANT_RULES || "";

  let contextBlock = "";

  if (context) {
    contextBlock =
      "\n\n[CONTEXTO]\n" +
      JSON.stringify(context, null, 2);
  }

  return `
${base}

${tone}

${rules}
${contextBlock}
`.trim();
}

module.exports = { buildAssistantPrompt };
